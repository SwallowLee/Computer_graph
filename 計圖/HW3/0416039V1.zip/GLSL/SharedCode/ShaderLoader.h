#ifndef SHADER_LOADER_H
#define SHADER_LOADER_H

bool ShaderLoad(unsigned int programId, char* shaderSrc, unsigned int shaderType);

#endif
